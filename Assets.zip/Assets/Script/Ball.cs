using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{   
    float speed = 200f;
    Rigidbody rigidBody;
    Vector3 velocity;
    Renderer _renderer;

    // Start is called before the first frame update
    void Start()
    {
        rigidBody = GetComponent<Rigidbody>();
        _renderer = GetComponent<Renderer>();     
        Invoke("Launch", 0.5f);   
    }

    void launch(){
        rigidBody.velocity = Vector3.down * speed;
    }

    void FixedUpdate()
    {
        rigidBody.velocity = rigidBody.velocity.normalized * speed;
        velocity = rigidBody.velocity;

        if(!_renderer.isVisible){
            GameManager.Instance.Balls--;
            Destroy(gameObject);
        }
    }

    private void OnCollisionEnter(Collision collision) {
        rigidBody.velocity = Vector3.Reflect(velocity, collision.contacts[0].normal);
    }
}
